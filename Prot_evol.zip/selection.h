int Selection(float fitness, float fitness_old, int N_pop);

// Old fitness functions
float Fitness_pow_E_a(float x_E, float x_alpha, float sel_coeff);
float Fitness_pow_min(float x_E, float x_alpha, float sel_coeff);
