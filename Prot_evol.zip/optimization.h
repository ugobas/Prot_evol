float Find_max_quad(float x1, float x2, float x3,
		    float y1, float y2, float y3,
		    float MIN, float MAX);
void Rearrange_points(float *x1, float *x2, float *x3,
		      float *y1, float *y2, float *y3,
		      float x0, float y0);
