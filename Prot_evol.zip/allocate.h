int ** Allocate_mat2_i(int n1, int n2, char *);
float  **Allocate_mat2_f(int n1, int n2, char *);
double **Allocate_mat2_d(int n1, int n2, char *);
void Empty_matrix_i(int **matrix, int N);
void Empty_matrix_f(float **matrix, int N);
void Empty_matrix_d(double **matrix, int N);
