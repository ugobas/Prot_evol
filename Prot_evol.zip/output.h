FILE *Output_file(char *name_file, char *what, char *ext);
