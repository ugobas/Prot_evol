int Read_ali(float *Seq_id, short ***ali_seq, int *N_ali,
	     char *file_ali, short *i_seq, int L_seq_pdb, int L_str_pdb);
