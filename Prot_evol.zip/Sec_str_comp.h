double Compute_E_loc(int *i_sec, short *aa_seq, int L);
double Compute_E_loc_misf(short *aa_seq, int L);
void Initialize_E_loc(float T, float SEC_STR);
double Delta_E_loc(int i_sec, short aa_old, short aa_new);
double Mutate_E_loc_misf(int aa_old, int aa_new);
