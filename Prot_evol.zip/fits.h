double Logistic_fit(double *tau, double *r, float *y, int step, int n);
