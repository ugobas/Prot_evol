float **Str_mut_matrix(char *STR_MUT_TYPE, char *file_str_mut,
		       struct protein target, int *res_index);
